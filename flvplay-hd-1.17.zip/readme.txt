FLVPlay 1.17

In order to run this installer, you need to install Adobe Integrated Runtime first. Please go to http://get.adobe.com/air and install the runtime first, if it is not installed already. You could also visit http://www.riaforge.co.uk/go/flvplay for web based, fully automated FLVPlay installation (Flash player is required).